// Netlify Function: /.netlify/functions/chat
// API key dibaca dari Environment Variable Netlify (Site settings →
// Environment variables), TIDAK PERNAH ada di kode/HTML yang dikirim ke browser.

const CHAT_API_BASE = 'https://openrouter.ai/api/v1/chat/completions';
const CHAT_MODEL = 'anthropic/claude-sonnet-4-5';

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: JSON.stringify({ error: 'Method not allowed' }) };
  }

  const OPENROUTER_API_KEY = process.env.OPENROUTER_API_KEY;
  if (!OPENROUTER_API_KEY) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'OPENROUTER_API_KEY belum diisi di Environment Variables Netlify.' })
    };
  }

  let payload;
  try {
    payload = JSON.parse(event.body || '{}');
  } catch (e) {
    return { statusCode: 400, body: JSON.stringify({ error: 'Body request bukan JSON yang valid.' }) };
  }

  const { messages, systemPrompt } = payload;
  if (!Array.isArray(messages) || messages.length === 0) {
    return { statusCode: 400, body: JSON.stringify({ error: 'Field "messages" wajib berupa array dan tidak boleh kosong.' }) };
  }

  const msgs = systemPrompt
    ? [{ role: 'system', content: systemPrompt }, ...messages]
    : messages;

  try {
    const upstream = await fetch(CHAT_API_BASE, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${OPENROUTER_API_KEY}`,
        'Content-Type': 'application/json',
        'HTTP-Referer': 'https://auraai.app',
        'X-Title': 'Anjar AI'
      },
      body: JSON.stringify({ model: CHAT_MODEL, messages: msgs, max_tokens: 2000 })
    });

    if (upstream.status === 401 || upstream.status === 403) {
      return { statusCode: 502, body: JSON.stringify({ error: 'API Key ditolak provider (mungkin salah/habis masa berlaku).' }) };
    }
    if (upstream.status === 429) {
      return { statusCode: 429, body: JSON.stringify({ error: 'Kuota chat habis / terlalu banyak permintaan. Coba lagi sebentar lagi.' }) };
    }
    if (!upstream.ok) {
      const errText = await upstream.text().catch(() => '');
      return { statusCode: upstream.status, body: JSON.stringify({ error: `API Error ${upstream.status}: ${errText.slice(0, 300)}` }) };
    }

    const data = await upstream.json();
    const reply = data?.choices?.[0]?.message?.content;
    if (!reply) {
      return { statusCode: 502, body: JSON.stringify({ error: 'Respons dari provider tidak berisi jawaban.' }) };
    }

    return { statusCode: 200, body: JSON.stringify({ reply }) };
  } catch (err) {
    return { statusCode: 502, body: JSON.stringify({ error: 'Gagal terhubung ke server AI: ' + err.message }) };
  }
};
