// Netlify Function: /.netlify/functions/image
// Opsional — hanya dipakai kalau frontend memilih provider gambar berbayar
// (OpenAI). Default Anjar AI memakai Pollinations.ai gratis tanpa key,
// jadi function ini hanya aktif kalau OPENAI_API_KEY diisi.

const IMAGE_API_BASE = 'https://api.openai.com/v1/images/generations';

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: JSON.stringify({ error: 'Method not allowed' }) };
  }

  const OPENAI_API_KEY = process.env.OPENAI_API_KEY;
  if (!OPENAI_API_KEY) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'OPENAI_API_KEY belum diisi di Environment Variables Netlify.' })
    };
  }

  let payload;
  try {
    payload = JSON.parse(event.body || '{}');
  } catch (e) {
    return { statusCode: 400, body: JSON.stringify({ error: 'Body request bukan JSON yang valid.' }) };
  }

  const { prompt, size, model } = payload;
  if (!prompt || typeof prompt !== 'string') {
    return { statusCode: 400, body: JSON.stringify({ error: 'Field "prompt" wajib diisi.' }) };
  }

  const candidates = [model, 'gpt-image-1', 'dall-e-3', 'dall-e-2'].filter((v, i, a) => v && a.indexOf(v) === i);
  let lastErr = null;

  for (const m of candidates) {
    try {
      const upstream = await fetch(IMAGE_API_BASE, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${OPENAI_API_KEY}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ model: m, prompt, n: 1, size: size || '1024x1024' })
      });

      if (upstream.status === 401 || upstream.status === 403) {
        return { statusCode: 502, body: JSON.stringify({ error: 'API Key gambar ditolak provider.' }) };
      }
      if (upstream.status === 429) {
        return { statusCode: 429, body: JSON.stringify({ error: 'Kuota generate gambar habis. Coba lagi nanti.' }) };
      }
      if (!upstream.ok) {
        const errText = await upstream.text().catch(() => '');
        if (/does not exist|model_not_found|unsupported|invalid model/i.test(errText)) {
          lastErr = new Error(errText.slice(0, 300));
          continue;
        }
        return { statusCode: upstream.status, body: JSON.stringify({ error: `Image API Error ${upstream.status}: ${errText.slice(0, 300)}` }) };
      }

      const data = await upstream.json();
      const item = data?.data?.[0];
      if (!item) return { statusCode: 502, body: JSON.stringify({ error: 'Server tidak mengembalikan gambar.' }) };

      if (item.url) return { statusCode: 200, body: JSON.stringify({ url: item.url }) };
      if (item.b64_json) return { statusCode: 200, body: JSON.stringify({ url: `data:image/png;base64,${item.b64_json}` }) };
      return { statusCode: 502, body: JSON.stringify({ error: 'Format respons gambar tidak dikenali.' }) };
    } catch (err) {
      lastErr = err;
    }
  }

  return { statusCode: 502, body: JSON.stringify({ error: 'Gagal generate gambar: ' + (lastErr?.message || 'unknown error') }) };
};
