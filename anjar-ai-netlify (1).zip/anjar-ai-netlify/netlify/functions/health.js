// Netlify Function: /.netlify/functions/health
// Dipakai frontend untuk mengecek apakah Environment Variable API key
// sudah diisi di dashboard Netlify (tanpa membocorkan isi key-nya).

exports.handler = async () => {
  return {
    statusCode: 200,
    body: JSON.stringify({
      ok: true,
      chatKeyConfigured: !!process.env.OPENROUTER_API_KEY,
      imageKeyConfigured: !!process.env.OPENAI_API_KEY
    })
  };
};
