# Anjar AI — Deploy ke Netlify (API Key Aman)

API key disimpan sebagai **Environment Variable** di dashboard Netlify, BUKAN
di kode. Frontend (`public/index.html`) memanggil Netlify Functions
(`/.netlify/functions/chat`, `/.netlify/functions/image`), dan function
itulah yang menambahkan API key sebelum diteruskan ke OpenRouter/OpenAI.
Key tidak pernah dikirim ke browser pengguna.

## ⚠️ PENTING — Ganti API key lama dulu

Kalau kamu pernah menulis API key langsung di file HTML sebelumnya, anggap
key itu bocor:
1. **OpenRouter** → https://openrouter.ai/keys → revoke key lama, buat baru.
2. **OpenAI** (kalau pernah dipakai) → https://platform.openai.com/api-keys → revoke, buat baru.

## Struktur folder

```
anjar-ai-netlify/
├── netlify.toml                  ← konfigurasi deploy
├── package.json
├── public/
│   └── index.html                 ← Anjar AI, sudah tanpa key
└── netlify/
    └── functions/
        ├── chat.js                ← proxy ke OpenRouter (pakai OPENROUTER_API_KEY)
        ├── image.js               ← proxy ke OpenAI Images (pakai OPENAI_API_KEY, opsional)
        └── health.js              ← cek status key tanpa membocorkan isinya
```

## Cara Deploy — Opsi A: Drag & Drop (paling mudah, tanpa Git)

1. Buka https://app.netlify.com → login/daftar.
2. Klik **"Add new site" → "Deploy manually"**.
3. **Penting:** Netlify drag-and-drop biasanya hanya men-deploy folder statis
   tanpa Functions secara otomatis. Untuk memastikan Functions ikut ter-deploy,
   gunakan **Netlify CLI** (lihat Opsi B) — drag & drop saja tidak menjalankan
   folder `netlify/functions/`.

## Cara Deploy — Opsi B: Netlify CLI (disarankan, Functions ikut aktif)

1. Install Netlify CLI (sekali saja, butuh Node.js terpasang):
   ```bash
   npm install -g netlify-cli
   ```
2. Login ke akun Netlify:
   ```bash
   netlify login
   ```
3. Masuk ke folder project ini lewat terminal:
   ```bash
   cd anjar-ai-netlify
   ```
4. Inisialisasi & deploy:
   ```bash
   netlify init
   ```
   Pilih **"Create & configure a new site"**, ikuti instruksinya (boleh pilih
   nama acak, nanti bisa diganti di dashboard).
5. Deploy ke production:
   ```bash
   netlify deploy --prod
   ```

## Cara Deploy — Opsi C: Lewat GitHub (otomatis re-deploy tiap push)

1. Push folder ini ke repository GitHub baru (file `.gitignore` sudah
   mengecualikan `node_modules`, `.env`, dll).
2. Di dashboard Netlify: **"Add new site" → "Import an existing project"** →
   pilih GitHub → pilih repo ini.
3. Build settings akan otomatis terbaca dari `netlify.toml`
   (publish: `public`, functions: `netlify/functions`). Klik **Deploy**.

## Mengisi API Key (Environment Variables) — WAJIB

Setelah site dibuat (cara apa pun di atas), isi key di dashboard:

1. Buka site kamu di **app.netlify.com** → pilih site → **Site configuration**
   → **Environment variables**.
2. Klik **Add a variable**, tambahkan:
   - Key: `OPENROUTER_API_KEY`, Value: *(API key OpenRouter baru kamu)*
   - (Opsional) Key: `OPENAI_API_KEY`, Value: *(API key OpenAI, kalau pakai generate gambar berbayar)*
3. Klik **Save**.
4. **Trigger deploy ulang** supaya Environment Variable terbaca (Deploys →
   **Trigger deploy** → **Deploy site**). Environment Variable baru tidak
   otomatis berlaku ke deploy yang sudah berjalan sebelumnya.

## Cek apakah sudah berhasil

Buka `https://nama-site-kamu.netlify.app` lalu masuk sebagai Tamu/Google,
coba chat. Kalau ada masalah, cek:
- **Site → Functions** di dashboard Netlify untuk melihat log error function.
- Buka `https://nama-site-kamu.netlify.app/.netlify/functions/health` langsung
  di browser — harus muncul `{"ok":true,"chatKeyConfigured":true,...}`. Kalau
  `chatKeyConfigured` masih `false`, berarti Environment Variable belum
  ter-set dengan benar atau belum di-redeploy.

## Soal Login Google (Firebase)

Domain Netlify kamu (`nama-site-kamu.netlify.app`, dan domain custom kalau
ada) perlu ditambahkan di:
**Firebase Console → Authentication → Settings → Authorized domains → Add domain**

Tanpa ini, tombol "Masuk dengan Google" akan gagal dengan error
`auth/unauthorized-domain`.

## Catatan keamanan

- File `netlify/functions/*.js` boleh aman di-push ke GitHub publik — file
  itu **membaca** API key dari `process.env`, tidak menuliskannya langsung.
- Jangan pernah membuat file `.env` berisi key asli lalu meng-commit-nya;
  `.gitignore` sudah mengecualikan `.env`, tapi tetap hati-hati.
- Netlify Functions gratis tidak punya rate limiting bawaan — sebagai jaga-jaga,
  set batas kuota/budget di dashboard OpenRouter/OpenAI supaya tidak kebobolan
  kalau ada penyalahgunaan.
